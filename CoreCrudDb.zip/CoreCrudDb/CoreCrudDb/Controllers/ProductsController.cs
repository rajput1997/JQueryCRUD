﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CoreCrudDb.Models;
using CoreCrudDb.Respository;
using CoreCrudDb.Models.ViewModel;
using Microsoft.AspNetCore.Hosting;
using System.IO;

namespace CoreCrudDb.Controllers
{
    public class ProductsController : Controller
    {
        private readonly IProduct productRepo;

        public IHostingEnvironment environment { get; }

        public ProductsController(IProduct product, IHostingEnvironment _environment)
        {
            this.productRepo = product;
            environment = _environment;
        }
        public IActionResult Index()
        {
            //var products = productRepo.GetProducts();
            //var cates = productRepo.GetCategories();
            //ProductCategoryModel obj = new ProductCategoryModel()
            //{
            //    Products = products,
            //    Categories = cates
            //};
            //return View(obj);
            var prods = productRepo.GetProductViews();     
            return View(prods);
        }

        public IActionResult Create()
        {
            var cats = productRepo.GetCategories();
            ViewBag.cats = cats;
            return View();
        } 
        
        [HttpPost]
        public IActionResult Create(CreateProduct product)
        {
            if (ModelState.IsValid)
            {

                string path = environment.WebRootPath;
                string fullPath = Path.Combine(path, "images", product.Image.FileName);

                FileStream stream = new FileStream(fullPath, FileMode.Create);
                product.Image.CopyTo(stream);

                productRepo.PostProduct(product);

                return RedirectToAction("Index");
            }
            else
            {
                var cats = productRepo.GetCategories();
                ViewBag.cats = cats;
                return View(product);
            }

        }

        public IActionResult Delete(int id)
        {
            productRepo.DeleteProduct(id);
            return RedirectToAction("Index");
        }

        public IActionResult Update(int id)
        {
           return View(productRepo.GetProductById(id));

        }

        [HttpPost]
        public IActionResult Update(Product pro)
        {
            productRepo.UpdateProduct(pro);
            return RedirectToAction("Index");
        }
        public IActionResult AddCategory()
        {
            return View();
        } 

        [HttpPost]
        public IActionResult CreateCategory(Category category)
        {
            productRepo.CreateCategory(category);

            return RedirectToAction("Index");
        }

        public IActionResult ShowCategory()
        {
            var cats = productRepo.GetCategories();
            return View(cats);
        }
        public IActionResult ShowProducts(int id)
        {
            var prods = productRepo.GetProductByCategory(id);
            return View(prods);
        }

        
    }
}
