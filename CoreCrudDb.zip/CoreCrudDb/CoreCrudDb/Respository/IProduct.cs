﻿using CoreCrudDb.Models;
using CoreCrudDb.Models.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreCrudDb.Respository
{
   public interface IProduct
    {

        List<Product> GetProducts();
        CreateProduct PostProduct(CreateProduct pro);

        Product GetProductById(int id);
        bool DeleteProduct(int id);
        Product UpdateProduct(Product pro);

        Category CreateCategory(Category cc);
        List<Category> GetCategories();

        List<ProductViewModel> GetProductViews();

        List<Product> GetProductByCategory(int id);
    }
}
