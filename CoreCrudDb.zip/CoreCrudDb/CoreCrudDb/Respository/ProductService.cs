﻿using CoreCrudDb.Models;
using CoreCrudDb.Models.ViewModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace CoreCrudDb.Respository
{
    public class ProductService:IProduct
    {
        private readonly ApplicationContext context;

        public ProductService(ApplicationContext context)
        {
            this.context = context;
        }

        public bool DeleteProduct(int id)
        {
            var product = context.Products.SingleOrDefault(e => e.Id == id);
            if (product != null)
            {
                product.IsActive = false;
                context.Products.Update(product);
                context.SaveChanges();
                return true;
            }
            return false;
        }

        public Product GetProductById(int id)
        {
            var product = context.Products.SingleOrDefault(e => e.Id == id && e.IsActive==true);
            return product;
        }

        public List<Product> GetProducts()
        {
            var products = context.Products.Where(e=>e.IsActive==true).ToList();
            return products;
        }

        public CreateProduct PostProduct(CreateProduct pro)
        {
            // pro.IsActive = true;
            var cat = context.Categories.SingleOrDefault(e => e.Id == pro.CategoryId);
            string dbPath = Path.Combine("images", pro.Image.FileName);
            var prod = new Product()
            {
                Title=pro.Title,
                Price=pro.Price,
                Quantity=pro.Quantity,
                IsActive=pro.IsActive,
                Category=cat,
                Image=dbPath
            };
            this.context.Products.Add(prod);
            context.SaveChanges();
            return pro;
        }

        public Product UpdateProduct(Product pro)
        {
            this.context.Products.Update(pro);
            context.SaveChanges();
            return pro;
        }

        public Category CreateCategory(Category cc)
        {

            context.Categories.Add(cc);
            context.SaveChanges();
            return cc;
        }

        public List<Category> GetCategories()
        {
            return context.Categories.ToList();
        }

       public List<ProductViewModel> GetProductViews()
        {
            var prods = from prod in context.Products
                        join
                        cat in context.Categories
                        on prod.Category.Id equals cat.Id
                        where prod.IsActive==true
                        select new ProductViewModel()
                        {
                            Id=prod.Id,
                            Title=prod.Title,
                            Price=prod.Price,
                            Quantity=prod.Quantity,
                            IsActive=prod.IsActive,
                            Name=cat.Name,
                            Decription=cat.Decription,
                            Image=prod.Image

                        };
            return prods.ToList();

        }

       public List<Product> GetProductByCategory(int id)
        {
            var prods = context.Products.Where(e => e.Category.Id == id).ToList();
            return prods;
                
        }
    }
}
