﻿using EMSProject.Models.ViewModel;
using EMSProject.Respository.Contract;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EMSProject.Controllers
{
    [Authorize]
    public class EmployeeController : Controller
    {
        private IEmployee EmployeeService;
        public EmployeeController(IEmployee employee) {
            EmployeeService = employee;
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult GetEmployees()
        {
            var emps = EmployeeService.GetEmployees();
            return Json(emps);
        }
        public IActionResult GetDepartments()
        {
            var depts = EmployeeService.GetDepartments();
            return Json(depts);
        }

        [HttpPost]
        public IActionResult CreateEmployee(EmployeeViewModel model)
        {
            var result = EmployeeService.CreateEmployee(model);
            return Json(result);
        }

        [HttpPost]
        public IActionResult DeleteEmployee(int id)
        {
            var result = EmployeeService.DeleteEmployee(id);
            if (result)
            {
                return Json(new {ok=true, message = "employee deleted successfully.." });
            }
            else
            {
                return Json(new {ok=false, message = "employee not deleted found.." });
            }
        }
        [HttpGet]
        public IActionResult GetEmployee(int id)
        {
            var emp = EmployeeService.GetEmployeeById(id);
            return Json(emp);
        }

        [HttpPost]
        public IActionResult UpdateEmployee(EmployeeViewModel model)
        {
            var result = EmployeeService.UpdateEmployee(model);
            if (result != null)
            {
                return Json(new { ok = true, message = "employee updated successfully.." });
            }
            else
            {
                return Json(new { ok = false, message = "Something went wrong !" });
            }
        }

    }
}
