﻿using EMSProject.Models;
using EMSProject.Models.ViewModel;
using EMSProject.Respository.Contract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EMSProject.Respository.Service
{
    public class EmployeeService:IEmployee
    {
        private readonly EMSDBContext dbcontext;

        public EmployeeService(EMSDBContext context)
        {
            this.dbcontext = context;
        }

        public Employees CreateEmployee(EmployeeViewModel model)
        {
            var dept = dbcontext.Departments.SingleOrDefault(e => e.Id == model.Department);
            var emp = new Employees()
            {
                FirstName=model.FirstName,
                LastName=model.LastName,
                Email=model.Email,
                Mobile=model.Mobile,
                IsActive=model.IsActive,
                Department=dept
            };
            dbcontext.Employees.Add(emp);
            dbcontext.SaveChanges();
            return emp;
        }

        public List<Department> GetDepartments()
        {
            return dbcontext.Departments.ToList();
        }

        public List<Employees> GetEmployees()
        {
            return dbcontext.Employees.ToList();
        }

        public bool DeleteEmployee(int id)
        {
            var emp=dbcontext.Employees.SingleOrDefault(e => e.Id == id);
            if (emp != null)
            {
                dbcontext.Employees.Remove(emp);
                dbcontext.SaveChanges();
                return true;
            }
            else
            {
                return false;
            }
        }

        public Employees GetEmployeeById(int id)
        {
            return dbcontext.Employees.SingleOrDefault(e => e.Id == id);
        }

        public Employees UpdateEmployee(EmployeeViewModel emp)
        {
            var dept = dbcontext.Departments.SingleOrDefault(e => e.Id == emp.Department);

            var emp2 = dbcontext.Employees.SingleOrDefault(e => e.Id == emp.Id);

            emp2.FirstName = emp.FirstName;
            emp2.LastName = emp.LastName;
            emp2.Email = emp.Email;
            emp2.IsActive = emp.IsActive;
            emp2.Mobile = emp.Mobile;
            emp2.Image = "fake.jpg";
            emp2. Department = dept;
            
            dbcontext.Employees.Update(emp2);
            dbcontext.SaveChanges();
            return emp2;
        }
    }
}
