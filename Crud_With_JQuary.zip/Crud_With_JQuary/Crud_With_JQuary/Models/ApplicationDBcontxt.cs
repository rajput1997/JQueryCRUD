﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Crud_With_JQuary.Models
{
    public class ApplicationDBcontxt : DbContext
    {
        public ApplicationDBcontxt(DbContextOptions<ApplicationDBcontxt> options) : base(options) { }
        public DbSet<Employee> Employees { get; set; }
    }
}
